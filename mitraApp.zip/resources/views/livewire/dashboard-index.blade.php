<div>
    <section>
        <div class="page-header">
          <h1 class="page-title">
            Dashboard
          </h1>
        </div>
     
      </section>
      
      <section>
        @livewire('dashboard-kegiatan')
      </section>
      <section>
        @livewire('dashboard-penilaian')
      </section>
    
</div>
