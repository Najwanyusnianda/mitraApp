<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <style>
        body {
         height:297mm; 
         width:210mm;
         /* to centre page on screen*/
         margin-left: auto;
         margin-right: auto;
     }
     img{
         background-image: url("/sertifikat/sertifikat-01.png");
         width: 100%;
         background-size:cover;

    background-repeat: no-repeat;
    z-index: 0;
    position:fixed
     }
 </style>
</head>

<body>
<img src="{{ url("/sertifikat/sertifikat-01.png") }}" alt="" srcset="">
</body>
</html>