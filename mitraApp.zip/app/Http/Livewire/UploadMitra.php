<?php

namespace App\Http\Livewire;

use Livewire\Component;

class UploadMitra extends Component
{
    public function render()
    {
        return view('livewire.upload-mitra');
    }
}
