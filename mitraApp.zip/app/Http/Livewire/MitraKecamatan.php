<?php

namespace App\Http\Livewire;

use Livewire\Component;

class MitraKecamatan extends Component
{
    public function render()
    {
        return view('livewire.mitra-kecamatan');
    }
}
