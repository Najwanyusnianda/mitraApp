<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mitra extends Model
{
    //
    protected $guarded=[];
}
