<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KegiatanMitra extends Model
{
    //
    protected $guarded=[];
}
